<script>
  import { Router, Route } from 'svelte-routing';
  import Calendrier from './routes/Calendrier.svelte';
  import Events from './routes/Event/Events.svelte';
  import NewEvents from './routes/Event/newEvents.svelte';
  import EditEvents from './routes/Event/editEvents.svelte';
</script>

<Router>
  <Route
    path="/events/:year/:month/:day" let:params>
    <Events year={params.year} month={params.month} day={params.day}/>
  </Route>

  <Route
    path="/newEvents/:year/:month/:day" let:params>
    <NewEvents year={params.year} month={params.month} day={params.day}/>
  </Route>

  <Route
    path="/editEvents/:year/:month/:day/:eventTitle" let:params>
    <EditEvents year={params.year} month={params.month} day={params.day} eventTitle={params.eventTitle}/>
</Route>

  <Route path="/">
      <Calendrier />
  </Route>
</Router>