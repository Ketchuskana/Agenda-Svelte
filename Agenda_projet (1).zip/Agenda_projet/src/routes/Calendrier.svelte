<script>
    import { onMount } from 'svelte';
    import { navigate } from 'svelte-routing';
  
    let currentDate;
    let year;
    let month;
    let daysInMonth;
    let selectedDate = null;
    let selectedYear;
    let years = [];
    let eventsData = {};

    // Charger les évenements du localStorage
    function loadEvents() {
      eventsData = JSON.parse(localStorage.getItem('events')) || {};
    }
    

    onMount(() => {
      currentDate = new Date();
      year = currentDate.getFullYear();
      month = currentDate.getMonth() + 1;
      selectedYear = year;
      daysInMonth = new Date(year, month, 0).getDate();

      //Liste des annéess
      let currentYear = new Date().getFullYear();
      const yearsAhead = 30;
      const yearsPast = 10;
      for (let i = currentYear - yearsPast; i <= currentYear + yearsAhead; i++) {
          years.push(i);
      }

      loadEvents();
    });
  
    let daysOfMonth = [];
  
    $: {
      daysOfMonth = generateDaysOfMonth(selectedYear, month);
    }
  
    //Fonction pour générer les jours du mois choisi
    function generateDaysOfMonth(year, month) {
      const firstDayOfMonth = new Date(year, month - 1, 1).getDay();
      const daysInFirstWeek = 7 - (firstDayOfMonth === 0 ? 7 : firstDayOfMonth);
      let days = [];
  
      const lastDayOfPreviousMonth = new Date(year, month - 1, 0).getDate();
      for (let i = lastDayOfPreviousMonth - firstDayOfMonth + 2; i <= lastDayOfPreviousMonth; i++) {
        days.push(null);
      }
  
      for (let i = 1; i <= daysInMonth; i++) {
        days.push(i);
      }
  
      while (days.length % 7 !== 0) {
        days.push(null);
      }
  
      return days;
    }
  
    //Aller au mois précédent
    function previousMonth() {
      if (month === 1) {
        selectedYear--;
        month = 12;
      } else {
        month--;
      }
      daysInMonth = new Date(selectedYear, month, 0).getDate();
    }
  
    //aller au mois suivant
    function nextMonth() {
      if (month === 12) {
        selectedYear++;
        month = 1;
      } else {
        month++;
      }
      daysInMonth = new Date(selectedYear, month, 0).getDate();
    }
  
    const monthNames = [
      'Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin',
      'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'
    ];
   
    //Fonction pour sélectionner une date et aller ajouter des évènements
    function selectDate(date) {
      selectedDate = date;
      navigate(`/events/${year}/${month}/${date}`);
    }

     // Fonction pour récupérer les événements de la date sélectionnée
     function getEventsForDate(date) {
      const key = `${selectedYear}-${month}-${date}`;
      return eventsData[key] || [];
    }
    
    //Fonction pour mettre à jour le calendrier
    function updateCalendar() {
      daysInMonth = new Date(selectedYear, month, 0).getDate();
      daysOfMonth = generateDaysOfMonth(selectedYear, month);
    }

  </script>
  
  <main>
    <div class="year-container">
        <button class="arrow-button" on:click={previousMonth}>&lt;</button>
        <div class="year-selector">
          <div class="month-year">{monthNames[month - 1]}</div>
          <select bind:value={selectedYear} on:change={updateCalendar}>
            {#each years as yearOption}
              <option value={yearOption}>{yearOption}</option>
            {/each}
          </select>
        </div>
        <button class="arrow-button" on:click={nextMonth}>&gt;</button>
    </div>
  
    <div class="calendar">
        {#each ['Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim'] as day}
            <div class="day-cell">{day}</div>
        {/each}
        {#each daysOfMonth as day}
            {#if day !== null}
                {#if getEventsForDate(day).length > 0}
                    <div class="day-cell" on:click={() => selectDate(day)} style="position: relative;">
                      <div class="day-number">{day}</div>
                      <div class="events-list">
                        {#each getEventsForDate(day) as event}
                            <div class="event-title" style="background-color: {event.color};">
                                {event.title}
                            </div>
                        {/each}
                      </div>
                      </div>
                {:else}
                    <div class="day-cell" on:click={() => selectDate(day)}>{day}</div>
                {/if}
            {:else}
                <div class="empty-day-cell"></div>
            {/if}
        {/each}
    </div>
  </main>
  
  <style>
    .year-container {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 10px; 
        border: 1px solid #ccc; 
        border-radius: 5px;
        margin-bottom: 10px;
    }
  
    .arrow-button {
        background-color: transparent;
        color: #ffffff;
        border: none;
        font-size: 40px;
        cursor: pointer;
        transition: color 0.3s ease;
    }
  
    .arrow-button:hover {
        color: #df84d2;
    }
  
    .calendar {
        width: 100%;
        display: grid;
        grid-template-columns: repeat(7, 1fr);
        gap: 5px;
    }
  
    .year-selector {
      margin: 10px 0;
    }
  
    select {
      padding: 5px;
      border-radius: 5px;
      border: 1px solid #ccc;
    }
  
    .day-cell {
      border: 1px solid #ccc;
      width: 100px; 
      min-height: 100px;
      text-align: center;
      cursor: pointer;
      display: flex;
      flex-direction: column; 
      align-items: center;
      padding: 5px;
    }
  
    .event-title {
      width: 100%; 
      text-align: center;
      padding: 2px 0; 
      margin-top: 2px;
      white-space: nowrap;
      text-overflow: ellipsis;
    }
  
    .events-list {
      width: 100%; 
      display: flex;
      flex-direction: column; 
      align-items: center;
    }
  
  
    .empty-day-cell {
        width: 100px;
        height: 100px;
        border: 1px solid #ccc;
    }
  
    .month-year {
        font-size: 1.5rem;
        font-weight: bold;
    }
  
  @media (max-width: 768px) {
    .day-cell, .empty-day-cell {
        width: 100%;
        min-height: 80px;
    }
    .arrow-button {
        font-size: 30px;
    }
  }
  
  @media (max-width: 480px) {
    .year-container, .calendar, .day-cell, .empty-day-cell {
        padding: 5px;
        width: 100%;
    }
    .day-cell, .empty-day-cell {
        min-height: 60px;
    }
    .arrow-button {
        font-size: 20px;
    }
    .calendar {
        gap: 2px; 
    }
  }
  
  @media (max-width: 360px) {
    .month-year {
        font-size: 1.2rem;
    }
    .event-title {
        font-size: 0.8rem;
    }
  }
  
  </style>
  