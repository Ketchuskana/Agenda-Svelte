<script>
  import { navigate } from 'svelte-routing';
  import { onMount } from 'svelte';
  import { Link } from 'svelte-routing';

  let title = '';
  let startDate = '';
  let endDate = '';
  let color = '';
  let description = '';

  export let year;
  export let month;
  export let day;

  onMount(() => {
      year = year ? parseInt(year) : new Date().getFullYear();
      month = month ? parseInt(month) : new Date().getMonth() + 1;
      day = day ? parseInt(day) : new Date().getDate();
  });

  //Afficher automatiquement la date au jour choisi dans le calendrier
  startDate = `${year}-${month.toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}T00:00`;

  endDate = `${year}-${month.toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}T00:00`;

  function handleSubmit() {
      const eventData = {
          title,
          startDate,
          endDate,
          color,
          description
      };
      console.log(eventData);

      // Stocker le nouvel événement dans localStorage puis retourner à la page des évènements du jour
      const eventKey = `${year}-${month}-${day}`;
      let events = JSON.parse(localStorage.getItem('events')) || {};
      events[eventKey] = events[eventKey] || [];
      events[eventKey].push(eventData);
      localStorage.setItem('events', JSON.stringify(events));
      
      navigate(`/events/${year}/${month}/${day}`);
  }
</script>

<h1> Enregistrez votre nouvel évenement</h1>

<form on:submit|preventDefault={handleSubmit}>
  <label>
    Titre:
    <input type="text" bind:value={title} required />
  </label>

  <label>
    Date/Heure de début:
    <input type="datetime-local" bind:value={startDate} required />
  </label>

  <label>
    Date/Heure de fin:
    <input type="datetime-local" bind:value={endDate} />
  </label>

  <label>
    Couleur:
    <input type="color" bind:value={color} />
  </label>

  <label>
    Description:
    <textarea rows="4" bind:value={description}></textarea>
  </label>

  <button type="submit">Ajouter</button>
  <Link to={`/events/${year}/${month}/${day}`} title="Retour"> Retour &gt</Link>
</form>

<style>

  form {
    width: 100%;
    max-width: 400px;
    padding: 50px;
    border-radius: 10px;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
  }

  label {
    font-weight: bold;
    margin-bottom: 8px;
  }

  input,
  textarea {
    width: 100%;
    font: inherit;
    margin-bottom: 16px;
    padding: 10px;
    border: 1px solid #6a6868;
    border-radius: 5px;
   transition: border-color 0.3s ease;
    background: rgba(0, 0, 0, 0.03);
  transition: background 0.3s
      cubic-bezier(0.25, 0.1, 0.25, 1),
    border-color 0.3s
      cubic-bezier(0.25, 0.1, 0.25, 1);
  }

  input:focus,
  textarea:focus {
    outline: none;
    border-color: #007bff;
  }

  button[type="submit"] {
    width: 100%;
    padding: 10px;
    border: none;
    border-radius: 5px;
    background-color: #007bff;
    color: #fff;
    font-weight: bold;
    cursor: pointer;
    transition: background-color 0.3s ease;
  }

  button[type="submit"]:hover {
    background-color: #0056b3;
  }
</style>