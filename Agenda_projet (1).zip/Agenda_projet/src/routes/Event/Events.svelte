<script>
  import { writable } from 'svelte/store';
  import { navigate } from 'svelte-routing';
  import { onMount } from 'svelte';
  import { Link } from 'svelte-routing';

  // Création un store réactif pour les événements
  const eventsStore = writable([]);

  export let year;
  export let month;
  export let day;
  

  // Un tableau pour contenir les événements à afficher
  export let events = [];

  //Utilisation d'un store réactif
  eventsStore.subscribe(value => {
    events = value;
  });

  // Navigation vers la page d'ajout
  function handleAddEvent() {
    navigate(`/newEvents/${year}/${month}/${day}`);
  }

  // Navigation vers la page de modification en ajoutant le titre dans la clé
  function handleEditEvent(event) {
    navigate(`/editEvents/${year}/${month}/${day}/${event.title}`);
  }

  const eventKey = `${year}-${month}-${day}`;

  // Charger les événements du localStorage au chargement du composant
  onMount(() => {
    const storedEvents = JSON.parse(localStorage.getItem('events')) || {};
    eventsStore.set(storedEvents[eventKey] || []);
  });


  // Fonction pour supprimer un événement de la liste
  function deleteEvent(index) {
    events.splice(index, 1);
    localStorage.setItem('events', JSON.stringify({ ...JSON.parse(localStorage.getItem('events')), [eventKey]: events }));
    eventsStore.update(events => {
      return events;
    });
    updateLocalStorage();
  }

  // Fonction pour mettre à jour le localStorage avec la liste d'événements
  function updateLocalStorage() {
    const updatedEvents = eventsStore.get();
    localStorage.setItem('events', JSON.stringify({ ...JSON.parse(localStorage.getItem('events')), [eventKey]: updatedEvents }));
  }

</script>

<main>
  <h1>Vos événements pour le {day}/{month}/{year}</h1>

  <section style="display: flex; justify-content: space-between;">
    <Link to="/" title="Retour au calendrier"> &lt; Retour</Link>
    <Link to={`/newEvents/${year}/${month}/${day}`} title="Ajouter un evenement"> Ajouter un évènement &gt</Link>
  </section>
  
  <br>
  
  {#if events.length > 0}
    <div class="events-container">
      {#each events as event, index}
        <div class="event-item" style="background-color: {event.color}">
          <div class="event-title">{event.title}</div>
          <div class="event-details">
            <div>Heure de début: {new Date(event.startDate).toLocaleDateString()} à {new Date(event.startDate).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</div>
            <div>Heure de fin: {new Date(event.endDate).toLocaleDateString()} à {new Date(event.endDate).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</div>
            <div>Description: {event.description}</div>
          </div>
          <div class="buttons">
            <button on:click={() => deleteEvent(index)}>Supprimer</button>
            <button on:click={() => handleEditEvent(event)}>Modifier</button>
          </div>
        </div>
      {/each}
    </div>
  {:else}
    <p>Vous n'avez rien de prévu.</p>
  {/if}

</main>

<style>

  .events-container {
    display: grid;
    gap: 20px;
  }

  .event-item {
    border: 1px solid #ccc;
    border-radius: 5px;
    padding: 10px;
    position: relative;
  }

  .event-title {
    font-size: 18px;
    font-weight: bold;
    margin-bottom: 5px;
  }

  .event-details {
    font-size: 14px;
  }

  .buttons {
    position: absolute;
    top: 0;
    right: 0;
    margin-top: 10px;
    display: flex;
    width: 200px;
    gap: 10px;
    --b: 3px;
    --h: 50px;
  }

.buttons button {
  --_c: #000000;
  flex: calc(1.15 + var(--_s,0));
  min-width: 0;
  font-size: 14px;
  font-weight: bold;
  height: 30px;
  width: 80px;
  cursor: pointer;
  color: black;
  border: var(--b) solid var(--_c);
  background: 
    conic-gradient(at calc(100% - 1.3*var(--b)) 0,var(--_c) 209deg, #0000 211deg) 
    border-box;
  clip-path: polygon(0 0,100% 0,calc(100% - 0.577*var(--h)) 100%,0 100%);
  padding: 0 calc(0.288*var(--h)) 0 0;
  margin: 0 calc(-0.288*var(--h)) 0 0;
  box-sizing: border-box;
  transition: flex .4s;
}

.buttons button + button {
  --_c: #000000;
  flex: calc(.85 + var(--_s,0));
  background: 
    conic-gradient(from -90deg at calc(1.3*var(--b)) 100%,var(--_c) 119deg, #0000 121deg) 
    border-box;
  clip-path: polygon(calc(0.577*var(--h)) 0,100% 0,100% 100%,0 100%);
  margin: 0 0 0 calc(-0.288*var(--h));
  padding: 0 0 0 calc(0.288*var(--h));
}

.buttons button:focus-visible {
  outline-offset: calc(-2*var(--b));
  outline: calc(var(--b)/2) solid #000;
  background: none;
  clip-path: none;
  margin: 0;
  padding: 0;
}

.buttons button:focus-visible + button {
  background: none;
  clip-path: none;
  margin: 0;
  padding: 0;
}

.buttons button:has(+ button:focus-visible) {
  background: none;
  clip-path: none;
  margin: 0;
  padding: 0;
}

button:hover,
button:active:not(:focus-visible) {
  --_s: .75;
}

button:active {
  box-shadow: inset 0 0 0 100vmax var(--_c);
  color: #fff;
}

</style>